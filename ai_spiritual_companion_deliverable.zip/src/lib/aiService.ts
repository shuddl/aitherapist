import { Message, AIResponse } from './types';

// Mock AI service for demonstration purposes
// In a real implementation, this would connect to OpenAI or Anthropic APIs

// Generate AI response based on user input and conversation history
export const generateResponse = async (
  userInput: string, 
  conversationHistory: Message[]
): Promise<AIResponse> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  // For demonstration, we'll create responses based on keywords
  const input = userInput.toLowerCase();
  
  // Check if this should be an "insight" (highlighted with magenta accent)
  const isInsight = input.includes('why') || 
                    input.includes('help') || 
                    input.includes('understand') ||
                    Math.random() < 0.3; // 30% chance of being an insight
  
  let response = '';
  
  if (input.includes('anxious') || input.includes('anxiety')) {
    response = "I notice you're feeling anxious. Remember that anxiety often comes from focusing on an uncertain future. Let's bring your awareness to the present moment. Take three deep breaths with me, and notice the sensations in your body. What specifically is causing this anxiety?";
  } 
  else if (input.includes('meditation') || input.includes('meditate')) {
    response = "Meditation is a powerful practice for spiritual growth. The key is consistency rather than duration. Start with just 5 minutes of focusing on your breath. When thoughts arise, simply notice them without judgment, and gently return to your breath. Would you like to try a brief guided meditation now?";
  }
  else if (input.includes('peace') || input.includes('calm')) {
    response = "Inner peace comes from accepting what is, rather than resisting our current reality. Notice if you're holding tension in your body right now. Allow your shoulders to relax, your jaw to soften. Peace isn't found in changing our circumstances, but in changing our relationship to them. What specific situation feels most challenging right now?";
  }
  else if (input.includes('spiritual') || input.includes('journey')) {
    response = "Your spiritual journey is uniquely yours. Rather than seeking answers outside yourself, true wisdom comes from listening to your inner voice. What practices or experiences have felt most meaningful to you so far? And what are you currently seeking to understand more deeply?";
  }
  else if (input.includes('purpose') || input.includes('meaning')) {
    response = "Finding purpose often comes not from grand revelations, but from paying attention to what brings you alive. Notice what activities cause you to lose track of time, or what injustices stir your heart. Your purpose likely lies at the intersection of your gifts and what the world needs. What activities bring you the greatest sense of flow?";
  }
  else {
    // Default responses for other inputs
    const defaultResponses = [
      "That's an interesting perspective. How did you come to that understanding?",
      "I sense there's something deeper beneath what you're sharing. Can you tell me more about what you're feeling?",
      "Sometimes the questions we ask are more important than the answers. What question is most alive for you right now?",
      "The path to spiritual growth often involves embracing uncertainty. How comfortable are you with not knowing?",
      "Many spiritual traditions emphasize the importance of presence. How connected do you feel to the present moment right now?",
      "Your awareness of this shows deep self-reflection. What other patterns have you noticed in your spiritual journey?",
      "That's a profound insight. How might you integrate this understanding into your daily practice?"
    ];
    
    // Select a random default response
    response = defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
  }
  
  return {
    text: response,
    isInsight
  };
};

// Generate conversation suggestions based on conversation history
export const generateSuggestions = async (
  conversationHistory: Message[],
  latestAIMessage: Message
): Promise<string[]> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // In a real implementation, this would analyze the conversation and generate contextual suggestions
  // For demonstration, we'll provide suggestions based on the latest AI message
  
  const text = latestAIMessage.text.toLowerCase();
  
  if (text.includes('anxiety') || text.includes('anxious')) {
    return [
      "I'm feeling overwhelmed by uncertainty",
      "How can I ground myself when anxious?",
      "Are there breathing techniques that help?",
      "I want to understand the root of my anxiety"
    ];
  }
  else if (text.includes('meditation') || text.includes('meditate')) {
    return [
      "Yes, guide me through a meditation",
      "I struggle with quieting my mind",
      "How often should I meditate?",
      "What type of meditation is best for beginners?"
    ];
  }
  else if (text.includes('peace') || text.includes('calm')) {
    return [
      "Work stress is challenging me",
      "How can I find peace in chaos?",
      "I feel peaceful in nature",
      "Tell me about acceptance practices"
    ];
  }
  else if (text.includes('spiritual') || text.includes('journey')) {
    return [
      "I feel disconnected from my spirituality",
      "How do I deepen my practice?",
      "I'm drawn to different spiritual traditions",
      "What role does community play in spirituality?"
    ];
  }
  else if (text.includes('purpose') || text.includes('meaning')) {
    return [
      "I feel lost about my direction",
      "How do I recognize my purpose?",
      "Can purpose change over time?",
      "I want to make a meaningful contribution"
    ];
  }
  else {
    // Default suggestions
    return [
      "Tell me more about spiritual growth",
      "How can I develop more self-awareness?",
      "I'd like guidance on mindfulness",
      "What practices might help me connect with my inner wisdom?"
    ];
  }
};
