import { FC, RefObject } from 'react';
import { Message } from '../lib/types';

interface MessageListProps {
  messages: Message[];
  isLoading: boolean;
  messagesEndRef: RefObject<HTMLDivElement>;
}

const MessageList: FC<MessageListProps> = ({ messages, isLoading, messagesEndRef }) => {
  return (
    <div className="conversation-container">
      {messages.map((message) => (
        <div 
          key={message.id} 
          className={`message-container ${message.sender === 'user' ? 'user-message' : 'ai-message'} fade-in`}
        >
          {message.isInsight && (
            <div className="insight-indicator"></div>
          )}
          <p className="conversation-text">{message.text}</p>
        </div>
      ))}
      
      {isLoading && (
        <div className="message-container ai-message fade-in">
          <div className="loading-indicator">
            <div className="loading-dot"></div>
            <div className="loading-dot"></div>
            <div className="loading-dot"></div>
          </div>
        </div>
      )}
      
      <div ref={messagesEndRef} />
    </div>
  );
};

export default MessageList;
