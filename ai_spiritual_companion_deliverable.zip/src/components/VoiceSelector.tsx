import { FC } from 'react';
import { Voice } from '../lib/types';

interface VoiceSelectorProps {
  selectedVoice: Voice;
  onSelectVoice: (voice: Voice) => void;
}

const VoiceSelector: FC<VoiceSelectorProps> = ({ selectedVoice, onSelectVoice }) => {
  // Predefined voice options based on psychological comfort factors
  const voiceOptions: Voice[] = [
    {
      id: 'calm-female',
      name: 'Calm Female',
      gender: 'female',
      description: 'A warm, nurturing voice with gentle tones'
    },
    {
      id: 'wise-female',
      name: 'Wise Female',
      gender: 'female',
      description: 'A mature, insightful voice with soothing qualities'
    },
    {
      id: 'calm-male',
      name: 'Calm Male',
      gender: 'male',
      description: 'A steady, reassuring voice with grounded presence'
    },
    {
      id: 'wise-male',
      name: 'Wise Male',
      gender: 'male',
      description: 'A thoughtful, contemplative voice with depth'
    }
  ];

  return (
    <div className="voice-selector fade-in">
      <h3 className="text-sm mb-2">Select Voice</h3>
      <div className="hairline-dark mb-2"></div>
      {voiceOptions.map((voice) => (
        <div
          key={voice.id}
          className={`voice-option ${selectedVoice.id === voice.id ? 'selected' : ''}`}
          onClick={() => onSelectVoice(voice)}
        >
          <div className="text-sm">{voice.name}</div>
          <div className="text-xs text-gray-400">{voice.description}</div>
        </div>
      ))}
    </div>
  );
};

export default VoiceSelector;
