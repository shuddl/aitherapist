import { FC, KeyboardEvent } from 'react';

interface InputAreaProps {
  inputText: string;
  setInputText: (text: string) => void;
  handleSendMessage: (text: string) => void;
  isRecording: boolean;
  toggleRecording: () => void;
}

const InputArea: FC<InputAreaProps> = ({
  inputText,
  setInputText,
  handleSendMessage,
  isRecording,
  toggleRecording
}) => {
  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage(inputText);
    }
  };

  return (
    <div className="input-container">
      <input
        type="text"
        className="input-field"
        placeholder="Share your thoughts..."
        value={inputText}
        onChange={(e) => setInputText(e.target.value)}
        onKeyDown={handleKeyDown}
      />
      <button
        className={`voice-button ${isRecording ? 'active' : ''}`}
        onClick={toggleRecording}
        aria-label={isRecording ? 'Stop recording' : 'Start recording'}
      >
        🎤
      </button>
      <button
        className="send-button"
        onClick={() => handleSendMessage(inputText)}
        aria-label="Send message"
      >
        ➤
      </button>
    </div>
  );
};

export default InputArea;
