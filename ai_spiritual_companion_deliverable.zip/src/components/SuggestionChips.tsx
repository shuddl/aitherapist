import { FC } from 'react';

interface SuggestionChipsProps {
  suggestions: string[];
  onSuggestionClick: (suggestion: string) => void;
}

const SuggestionChips: FC<SuggestionChipsProps> = ({ suggestions, onSuggestionClick }) => {
  return (
    <div className="suggestions-container" style={{ padding: '0 16px 8px 16px' }}>
      {suggestions.map((suggestion, index) => (
        <button
          key={index}
          className={`suggestion-chip fade-in ${index === 0 ? 'accent' : ''}`}
          onClick={() => onSuggestionClick(suggestion)}
        >
          {suggestion}
        </button>
      ))}
    </div>
  );
};

export default SuggestionChips;
