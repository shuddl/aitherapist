import { useState, useEffect, useRef } from 'react';
import './App.css';
import VoiceSelector from './components/VoiceSelector';
import MessageList from './components/MessageList';
import InputArea from './components/InputArea';
import SuggestionChips from './components/SuggestionChips';
import { Message, Voice } from './lib/types';
import { generateResponse, generateSuggestions } from './lib/aiService';

function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showVoiceSelector, setShowVoiceSelector] = useState(false);
  const [selectedVoice, setSelectedVoice] = useState<Voice>({
    id: 'calm-female',
    name: 'Calm Female',
    gender: 'female',
    description: 'A warm, nurturing voice with gentle tones'
  });
  const [suggestions, setSuggestions] = useState<string[]>([]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load conversation history from localStorage on initial load
  useEffect(() => {
    const savedMessages = localStorage.getItem('conversationHistory');
    if (savedMessages) {
      setMessages(JSON.parse(savedMessages));
    } else {
      // Initial welcome message
      const initialMessage: Message = {
        id: '1',
        text: 'Hello, I am your spiritual companion. I\'m here to support your journey of self-discovery and growth. How are you feeling today?',
        sender: 'ai',
        timestamp: new Date().toISOString(),
        isInsight: false
      };
      setMessages([initialMessage]);
      
      // Initial suggestions
      setSuggestions([
        'I\'m feeling anxious today',
        'I need guidance with meditation',
        'Help me find inner peace',
        'I want to discuss my spiritual journey'
      ]);
    }
    
    const savedVoice = localStorage.getItem('selectedVoice');
    if (savedVoice) {
      setSelectedVoice(JSON.parse(savedVoice));
    }
  }, []);

  // Save messages to localStorage whenever they change
  useEffect(() => {
    if (messages.length > 0) {
      localStorage.setItem('conversationHistory', JSON.stringify(messages));
    }
  }, [messages]);

  // Save selected voice to localStorage
  useEffect(() => {
    localStorage.setItem('selectedVoice', JSON.stringify(selectedVoice));
  }, [selectedVoice]);

  // Scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Handle sending a message
  const handleSendMessage = async (text: string) => {
    if (!text.trim()) return;
    
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      text,
      sender: 'user',
      timestamp: new Date().toISOString(),
      isInsight: false
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);
    
    try {
      // In a real implementation, this would call the actual AI service
      const response = await generateResponse(text, messages);
      
      // Add AI response
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: response.text,
        sender: 'ai',
        timestamp: new Date().toISOString(),
        isInsight: response.isInsight
      };
      
      setMessages(prev => [...prev, aiMessage]);
      
      // Generate new suggestions based on conversation
      const newSuggestions = await generateSuggestions(messages, aiMessage);
      setSuggestions(newSuggestions);
      
      // In a real implementation, this would trigger voice synthesis
      if (selectedVoice) {
        // playVoice(response.text, selectedVoice.id);
        console.log(`Playing voice: ${selectedVoice.name} saying: ${response.text}`);
      }
    } catch (error) {
      console.error('Error generating response:', error);
      
      // Add error message
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: 'I apologize, but I encountered an issue. Please try again.',
        sender: 'ai',
        timestamp: new Date().toISOString(),
        isInsight: false
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle suggestion click
  const handleSuggestionClick = (suggestion: string) => {
    handleSendMessage(suggestion);
  };

  // Toggle voice recording
  const toggleRecording = () => {
    setIsRecording(!isRecording);
    // In a real implementation, this would start/stop voice recording
    console.log(isRecording ? 'Stopping recording' : 'Starting recording');
  };

  // Toggle voice selector
  const toggleVoiceSelector = () => {
    setShowVoiceSelector(!showVoiceSelector);
  };

  // Select a voice
  const handleSelectVoice = (voice: Voice) => {
    setSelectedVoice(voice);
    setShowVoiceSelector(false);
  };

  return (
    <div className="app-container">
      <div className="asymmetric-container">
        <header className="header">
          <h1>Spiritual Companion</h1>
          <button 
            onClick={toggleVoiceSelector} 
            className="voice-settings-button"
            aria-label="Voice settings"
          >
            {selectedVoice.gender === 'female' ? '♀' : '♂'}
          </button>
        </header>
        
        <MessageList 
          messages={messages} 
          isLoading={isLoading} 
          messagesEndRef={messagesEndRef}
        />
        
        <SuggestionChips 
          suggestions={suggestions} 
          onSuggestionClick={handleSuggestionClick} 
        />
        
        <InputArea 
          inputText={inputText}
          setInputText={setInputText}
          handleSendMessage={handleSendMessage}
          isRecording={isRecording}
          toggleRecording={toggleRecording}
        />
        
        {showVoiceSelector && (
          <VoiceSelector 
            selectedVoice={selectedVoice} 
            onSelectVoice={handleSelectVoice} 
          />
        )}
      </div>
    </div>
  );
}

export default App;
